package com.mysql.SpringBoot_Mysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
